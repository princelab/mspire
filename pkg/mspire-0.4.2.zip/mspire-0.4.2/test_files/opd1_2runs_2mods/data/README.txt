Some tags associated with the mzXML format are off because of the way we've modified the file to have only 20 scans!

!!!! These are wrong!!!!
<indexOffset>13623066</indexOffset>
<sha1>f7c9ccdd385f0cfc124cc6d0ca3e2bb36e4a9090</sha1>

