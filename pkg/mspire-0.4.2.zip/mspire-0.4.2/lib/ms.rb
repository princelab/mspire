

module MS
  attr_accessor :spectra

  # should
  def new(file=nil)
  end

end
