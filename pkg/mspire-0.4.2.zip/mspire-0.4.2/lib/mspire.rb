
module Mspire
  Version = '0.4.2'
end
